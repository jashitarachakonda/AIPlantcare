import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User table (keeping the existing users table from the original schema)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Plants table for storing identified plants
export const plants = pgTable("plants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  scientificName: text("scientific_name").notNull(),
  imageUrl: text("image_url").notNull(),
  confidence: integer("confidence"),
  healthStatus: text("health_status").notNull(),
  healthAssessment: text("health_assessment").notNull(),
  growthStage: text("growth_stage").notNull(),
  type: text("type").notNull(),
  lightNeeds: text("light_needs").notNull(),
  temperatureNeeds: text("temperature_needs").notNull(),
  humidityNeeds: text("humidity_needs").notNull(),
  wateringFrequency: text("watering_frequency").notNull(),
  soilNeeds: text("soil_needs").notNull(),
  pruningNeeds: text("pruning_needs").notNull(),
  repottingNeeds: text("repotting_needs").notNull(),
  funFact: text("fun_fact"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Plant scans table to keep history of plant identifications
export const plantScans = pgTable("plant_scans", {
  id: serial("id").primaryKey(),
  plantId: integer("plant_id").references(() => plants.id).notNull(),
  userId: integer("user_id").references(() => users.id),
  imageUrl: text("image_url").notNull(),
  healthStatus: text("health_status").notNull(),
  healthDetails: jsonb("health_details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define relations
export const plantsRelations = relations(plants, ({ many, one }) => ({
  scans: many(plantScans),
  user: one(users, { fields: [plants.userId], references: [users.id] }),
}));

export const plantScansRelations = relations(plantScans, ({ one }) => ({
  plant: one(plants, { fields: [plantScans.plantId], references: [plants.id] }),
  user: one(users, { fields: [plantScans.userId], references: [users.id] }),
}));

// Zod schemas for validation
export const insertPlantSchema = createInsertSchema(plants, {
  name: (schema) => schema.min(1, "Plant name is required"),
  scientificName: (schema) => schema.min(1, "Scientific name is required"),
  imageUrl: (schema) => schema.min(1, "Image URL is required"),
  healthStatus: (schema) => schema.min(1, "Health status is required"),
});

export const insertPlantScanSchema = createInsertSchema(plantScans, {
  plantId: (schema) => schema.positive("Valid plant ID is required"),
  imageUrl: (schema) => schema.min(1, "Image URL is required"),
  healthStatus: (schema) => schema.min(1, "Health status is required"),
});

export type InsertPlant = z.infer<typeof insertPlantSchema>;
export type Plant = typeof plants.$inferSelect;
export type InsertPlantScan = z.infer<typeof insertPlantScanSchema>;
export type PlantScan = typeof plantScans.$inferSelect;
