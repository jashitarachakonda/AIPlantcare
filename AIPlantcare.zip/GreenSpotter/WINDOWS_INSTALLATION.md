# Windows Installation Guide for GreenSpotter

This guide provides specific steps for Windows users who are encountering issues with TensorFlow installation.

## TensorFlow Installation Issue on Windows

The error you're seeing is related to TensorFlow requiring Visual Studio Build Tools and specific Python configurations. Rather than installing these complex dependencies, we've created a simplified version that will work on Windows systems.

## Simple Windows Installation

1. Extract the project ZIP file to a folder on your computer
2. Open the folder in VS Code or navigate to it in Command Prompt
3. Run the Windows-specific setup script:
   ```
   setup-windows.bat
   ```

This script will:
- Use a modified package.json without TensorFlow dependencies
- Install all other required dependencies
- Set up the database configuration
- Create a simplified version of the plant detection module

## Manual Installation (if the script doesn't work)

If the automated script doesn't work, follow these steps manually:

1. Rename `fixed-package-windows.json` to `package.json`
2. Run `npm install`
3. Create a `.env` file with:
   ```
   DATABASE_URL=postgres://postgres:postgres@localhost:5432/greenspotter
   PLANT_ID_API_KEY=your_api_key_here
   ```
4. Run `npm run db:push` and `npm run db:seed`
5. Create a simplified plant detector by editing `client\src\lib\plantDetector.ts`:
   ```javascript
   export async function isPlant(imageDataUrl) {
     // Simple bypass that always returns true
     return true;
   }
   ```

## Running the Application

After installation is complete:

1. Run `npm run dev`
2. Open your browser to http://localhost:5000

## Important Note

This simplified version bypasses the TensorFlow-based plant detection that would normally happen in the browser. Instead, it will allow any image to be sent to the server for analysis.

The server-side plant detection (using the Plant.ID API or the fallback algorithm) will still function normally.

## Using the Plant.ID API Key

For the best plant identification experience:

1. Get a Plant.ID API key from [their website](https://plant.id/)
2. Add it to your .env file as PLANT_ID_API_KEY=your_key_here
3. Restart the application

## For Best Results Without Plant.ID API

When using the application without a Plant.ID API key:

1. Include plant identifiers in your image filenames:
   - For Tulsi/Holy Basil: Include "tulsi", "holy", or "basil" in the filename
   - For Money Plant/Golden Pothos: Include "money", "pothos", or "golden" in the filename

2. Use clear, well-lit photos of plants, ideally against a clean background