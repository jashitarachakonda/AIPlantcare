import { db } from "@db";
import { plants, plantScans } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { Plant, PlantScan } from "@shared/schema";
import fs from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";

export const storage = {
  // Plants
  async getPlants(): Promise<Plant[]> {
    return await db.query.plants.findMany({
      orderBy: [desc(plants.createdAt)]
    });
  },

  async getPlantById(id: number): Promise<Plant | undefined> {
    return await db.query.plants.findFirst({
      where: eq(plants.id, id)
    });
  },

  async insertPlant(plantData: Omit<Plant, "id" | "createdAt">): Promise<Plant> {
    const [plant] = await db.insert(plants).values(plantData).returning();
    return plant;
  },

  // Plant Scans (History)
  async getPlantScans(): Promise<PlantScan[]> {
    return await db.query.plantScans.findMany({
      orderBy: [desc(plantScans.createdAt)],
      with: {
        plant: true
      }
    });
  },

  async getPlantScanById(id: number): Promise<PlantScan | undefined> {
    return await db.query.plantScans.findFirst({
      where: eq(plantScans.id, id),
      with: {
        plant: true
      }
    });
  },

  async insertPlantScan(scanData: Omit<PlantScan, "id" | "createdAt">): Promise<PlantScan> {
    const [scan] = await db.insert(plantScans).values(scanData).returning();
    return scan;
  },

  // Helper function to save base64 image and get URL
  async saveImage(base64Image: string): Promise<string> {
    // Extract image data and format
    const matches = base64Image.match(/^data:image\/([A-Za-z-+\/]+);base64,(.+)$/);
    
    if (!matches || matches.length !== 3) {
      throw new Error('Invalid base64 image format');
    }
    
    const imageFormat = matches[1];
    const imageData = matches[2];
    const buffer = Buffer.from(imageData, 'base64');
    
    try {
      // Create uploads directory if it doesn't exist
      const uploadsDir = path.join(process.cwd(), 'dist', 'public', 'uploads');
      await fs.mkdir(uploadsDir, { recursive: true });
      
      // Generate unique filename
      const filename = `${randomUUID()}.${imageFormat}`;
      const filePath = path.join(uploadsDir, filename);
      
      // Write file
      await fs.writeFile(filePath, buffer);
      
      // Return the URL path
      return `/uploads/${filename}`;
    } catch (error) {
      console.error('Error saving image:', error);
      throw new Error('Failed to save image');
    }
  }
};
