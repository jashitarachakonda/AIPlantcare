#!/bin/bash

echo "Setting up GreenSpotter Plant Identification App..."
echo ""

# Check if package.json exists
if [ -f "package.json" ]; then
    echo "Replacing package.json with fixed version..."
    rm package.json
else
    echo "No existing package.json found."
fi

# Rename fixed package.json
if [ -f "fixed-package.json" ]; then
    mv fixed-package.json package.json
    echo "package.json replaced successfully."
else
    echo "ERROR: fixed-package.json not found!"
    echo "Please make sure you have the fixed-package.json file in the current directory."
    exit 1
fi

echo ""
echo "Installing dependencies..."
npm install

echo ""
echo "Creating .env file..."
cat > .env << EOL
DATABASE_URL=postgres://postgres:postgres@localhost:5432/greenspotter
PLANT_ID_API_KEY=your_api_key_here
EOL

echo ""
echo "Created .env file with default PostgreSQL credentials."
echo "Please edit the .env file if your PostgreSQL credentials are different."

echo ""
echo "Setting up database..."
npm run db:push
npm run db:seed

echo ""
echo "Setup complete!"
echo ""
echo "To start the application, run: npm run dev"
echo "Then open your browser to: http://localhost:5000"
echo ""
echo "For more details, see the INSTALLATION_GUIDE.md file."
echo ""

read -p "Press Enter to continue..."