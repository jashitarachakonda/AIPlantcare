# Installation Guide for GreenSpotter Plant Identification App

This guide will help you set up and run the GreenSpotter Plant Identification application on your local machine using VS Code.

## Prerequisites

- [Node.js](https://nodejs.org/) (version 18 or higher)
- [PostgreSQL](https://www.postgresql.org/download/) installed and running
- [Visual Studio Code](https://code.visualstudio.com/)
- [Git](https://git-scm.com/) (optional)

## Step 1: Download and Extract the Project

1. Download the project zip file from Replit
2. Extract it to a folder on your computer
3. Open the folder in VS Code

## Step 2: Fix Package.json

One important step when downloading from Replit is to replace the package.json file. 
I've included a ready-to-use version called `fixed-package.json`.

1. Delete the existing `package.json` file (if it exists)
2. Rename `fixed-package.json` to `package.json`

## Step 3: Set Up PostgreSQL Database

1. Create a new PostgreSQL database for the project:
   ```
   createdb greenspotter
   ```

2. Create a `.env` file in the project root with the following content (adjust as needed):
   ```
   DATABASE_URL=postgres://username:password@localhost:5432/greenspotter
   PLANT_ID_API_KEY=your_api_key_if_available
   ```
   
   Replace `username` and `password` with your PostgreSQL credentials.

## Step 4: Install Dependencies

Open a terminal in VS Code and run:

```bash
npm install
```

This will install all the required dependencies for the project.

## Step 5: Set Up the Database Schema and Seed Data

Run these commands:

```bash
npm run db:push
npm run db:seed
```

This will create the necessary database tables and populate them with initial data.

## Step 6: Start the Application

Run:

```bash
npm run dev
```

The application should start and be accessible at http://localhost:5000

## Using the App

1. After starting the app, open your browser to http://localhost:5000
2. You can upload images through the interface
3. For best results with plant identification, name your image files according to the plant type:
   - For Tulsi/Holy Basil: Include "tulsi", "holy", or "basil" in the filename
   - For Money Plant/Golden Pothos: Include "money", "pothos", or "golden" in the filename

## Troubleshooting

1. If you see package.json errors, make sure you've replaced it with the fixed version
2. If you have database connection issues, verify your PostgreSQL credentials in the .env file
3. If TensorFlow has issues, you might need to install additional dependencies:
   - On Windows: Microsoft Visual C++ Redistributable
   - On Linux: libcudnn and other tensorflow system dependencies

## Additional Notes

- The application uses TensorFlow.js for plant detection, which might require additional setup on some systems
- For the best experience, use Chrome or Firefox browser
- The app is optimized for both desktop and mobile devices