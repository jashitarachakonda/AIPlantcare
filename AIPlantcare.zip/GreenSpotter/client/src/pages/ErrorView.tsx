import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { usePlant } from '@/context/PlantContext';

export default function ErrorView() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { setCurrentImage } = usePlant();

  const handleTryAgain = () => {
    setLocation('/');
  };

  const handleUploadDifferent = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (evt) => {
        const dataUrl = evt.target?.result as string;
        setCurrentImage(dataUrl);
        setLocation('/');
      };
      
      reader.onerror = () => {
        toast({
          title: "Error",
          description: "Failed to read the image file",
          variant: "destructive"
        });
      };
      
      reader.readAsDataURL(file);
    };
    
    input.click();
  };

  return (
    <div className="flex-1 flex flex-col">
      <div className="container mx-auto px-4 py-8 flex-1 flex flex-col items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <div className="inline-block rounded-full bg-error-light bg-opacity-10 p-4 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-error" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            
            <h2 className="text-xl font-medium mb-3">Plant Identification Failed</h2>
            <p className="text-neutral-600 mb-6">We couldn't identify this plant. Please try again with a clearer image or a different plant.</p>
            
            <div className="flex flex-col gap-3">
              <Button 
                className="w-full py-3 bg-primary hover:bg-primary-dark text-white rounded-lg font-medium shadow-sm"
                onClick={handleTryAgain}
              >
                Try Again
              </Button>
              
              <Button 
                variant="outline"
                className="w-full py-3 bg-white text-primary border border-primary rounded-lg font-medium shadow-sm"
                onClick={handleUploadDifferent}
              >
                Upload Different Image
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
