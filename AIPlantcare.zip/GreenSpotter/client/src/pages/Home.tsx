import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import CameraView from '@/components/CameraView';
import ProcessingView from '@/components/ProcessingView';
import { usePlant } from '@/context/PlantContext';
import { identifyPlant } from '@/lib/api';
import { isPlant } from '@/lib/plantDetector';

export default function Home() {
  const [, setLocation] = useLocation();
  const { 
    currentImage, 
    setCurrentImage, 
    isProcessing, 
    setIsProcessing,
    setPlantDetails, 
    addToHistory 
  } = usePlant();

  useEffect(() => {
    const processImage = async () => {
      if (!currentImage || !isProcessing) return;

      try {
        console.log("Starting image processing...");
        
        // ADVANCED APPROACH WITH SERVER-SIDE PLANT DETECTION:
        // We send the image to our backend API which will:
        // 1. Use TensorFlow.js for color analysis to detect if it's a plant
        // 2. Only identify actual plants, rejecting non-plant objects (face, pencil, book, bottle)
        // 3. Return 404 error with clear message when non-plant objects are detected
        console.log("Sending image to smart plant identification API...");
        const result = await identifyPlant(currentImage);
        
        if (result) {
          console.log("Plant successfully identified:", result.name);
          setPlantDetails(result);
          addToHistory(result);
          setIsProcessing(false);
          setLocation('/results');
        } else {
          // If API returns no results, go to error page
          console.log("API returned no results - likely not a plant");
          setIsProcessing(false);
          setLocation('/error');
        }
      } catch (error) {
        console.error('Error processing image:', error);
        
        // Check for specific 404 error (no plant detected)
        let errorMessage = "Failed to process image";
        if (error && typeof error === 'object' && 'response' in error) {
          const response = error.response;
          if (response && typeof response === 'object') {
            // The server returned a 404 status specifically for non-plant images
            if ('status' in response && response.status === 404) {
              console.log("Server rejected image as not a plant");
              errorMessage = "No plant detected in this image";
            }
          }
        }
        
        console.log(`Error details: ${errorMessage}`);
        setIsProcessing(false);
        setLocation('/error');
      }
    };

    processImage();
  }, [currentImage, isProcessing, setIsProcessing, setLocation, setPlantDetails, addToHistory]);

  return (
    <div className="min-h-screen flex flex-col pb-14">
      <Header />
      <main className="flex-1 flex flex-col">
        {isProcessing ? <ProcessingView /> : <CameraView />}
      </main>
      <BottomNav />
    </div>
  );
}
