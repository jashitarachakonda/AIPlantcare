import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import BottomNav from '@/components/BottomNav';
import { usePlant } from '@/context/PlantContext';
import { useToast } from '@/hooks/use-toast';

export default function ResultsView() {
  const [, setLocation] = useLocation();
  const { plantDetails } = usePlant();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');

  if (!plantDetails) {
    setLocation('/');
    return null;
  }

  const handleGoBack = () => {
    setLocation('/');
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `PlantSnap: ${plantDetails.name}`,
          text: `Check out this plant I identified: ${plantDetails.name} (${plantDetails.scientificName}). It's ${plantDetails.healthStatus.toLowerCase()}.`,
        });
      } else {
        toast({
          title: "Share",
          description: "Sharing is not supported on this device",
        });
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col pb-14">
      {/* Plant Header */}
      <div className="relative">
        <div className="h-48 overflow-hidden">
          <img 
            src={plantDetails.imageUrl} 
            alt={plantDetails.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent"></div>
        </div>
        
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between">
          <Button 
            onClick={handleGoBack}
            className="w-10 h-10 p-0 bg-black/30 hover:bg-black/40 rounded-full flex items-center justify-center text-white"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
            </svg>
          </Button>
          <Button 
            onClick={handleShare}
            className="w-10 h-10 p-0 bg-black/30 hover:bg-black/40 rounded-full flex items-center justify-center text-white"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
            </svg>
          </Button>
        </div>
        
        <div className="absolute -bottom-16 left-4 right-4 bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-4 flex items-start gap-4">
            <div className="bg-primary-light bg-opacity-10 rounded-full p-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
              </svg>
            </div>
            <div className="flex-1 pt-1">
              <h2 className="text-xl font-semibold">{plantDetails.name}</h2>
              <p className="text-neutral-600 text-sm">{plantDetails.scientificName}</p>
            </div>
            <div className="flex-shrink-0 pt-1">
              <div className={`px-3 py-1 rounded-full ${
                plantDetails.healthStatus === 'Healthy' 
                  ? 'bg-success-light bg-opacity-10 text-success' 
                  : plantDetails.healthStatus === 'Needs attention'
                  ? 'bg-warning-light bg-opacity-10 text-warning'
                  : 'bg-error-light bg-opacity-10 text-error'
              }`}>
                <span className="text-sm font-medium">{plantDetails.healthStatus}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Plant Details Tabs */}
      <div className="container mx-auto px-4 mt-20 flex-1 pb-6">
        {/* Tabs Navigation */}
        <div className="flex border-b border-neutral-200 mb-4 mt-4">
          <button 
            className={`px-4 py-2 border-b-2 ${activeTab === 'overview' ? 'border-primary text-primary font-medium' : 'border-transparent text-neutral-600'}`} 
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button 
            className={`px-4 py-2 border-b-2 ${activeTab === 'care' ? 'border-primary text-primary font-medium' : 'border-transparent text-neutral-600'}`}
            onClick={() => setActiveTab('care')}
          >
            Care Tips
          </button>
          <button 
            className={`px-4 py-2 border-b-2 ${activeTab === 'health' ? 'border-primary text-primary font-medium' : 'border-transparent text-neutral-600'}`}
            onClick={() => setActiveTab('health')}
          >
            Health Status
          </button>
        </div>
        
        {/* Tab Content: Overview */}
        {activeTab === 'overview' && (
          <div className="fade-in">
            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-100">
                <p className="text-neutral-500 text-sm mb-1">Growth Estimation</p>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                  <p className="font-medium">{plantDetails.growthStage}</p>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-100">
                <p className="text-neutral-500 text-sm mb-1">Type</p>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                  </svg>
                  <p className="font-medium">{plantDetails.type}</p>
                </div>
              </div>
            </div>
            
            {/* Environment Requirements */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-6 border border-neutral-100">
              <h3 className="font-medium mb-3">Ideal Environment</h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <div className="w-10">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Light</p>
                    <p className="text-sm text-neutral-600">{plantDetails.lightNeeds}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-10">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Temperature</p>
                    <p className="text-sm text-neutral-600">{plantDetails.temperatureNeeds}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-10">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Humidity</p>
                    <p className="text-sm text-neutral-600">{plantDetails.humidityNeeds}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Fun Fact */}
            {plantDetails.funFact && (
              <div className="bg-primary bg-opacity-5 rounded-lg p-4 flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
                <div>
                  <p className="font-medium text-primary mb-1">Fun Fact</p>
                  <p className="text-sm text-neutral-700">{plantDetails.funFact}</p>
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Tab Content: Care Tips */}
        {activeTab === 'care' && (
          <div className="fade-in">
            <div className="bg-white rounded-lg shadow-sm border border-neutral-100 overflow-hidden mb-6">
              <div className="p-4 border-b border-neutral-100">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Watering</h3>
                    <p className="text-neutral-600 text-sm">{plantDetails.wateringFrequency}</p>
                  </div>
                </div>
              </div>
              <div className="p-4 border-b border-neutral-100">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Soil & Fertilizer</h3>
                    <p className="text-neutral-600 text-sm">{plantDetails.soilNeeds}</p>
                  </div>
                </div>
              </div>
              <div className="p-4 border-b border-neutral-100">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758a3 3 0 10-4.243 4.243 3 3 0 004.243-4.243zm0-5.758a3 3 0 10-4.243-4.243 3 3 0 004.243 4.243z" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Pruning</h3>
                    <p className="text-neutral-600 text-sm">{plantDetails.pruningNeeds}</p>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Repotting</h3>
                    <p className="text-neutral-600 text-sm">{plantDetails.repottingNeeds}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Seasonal Care */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-100 p-4 mb-6">
              <h3 className="font-medium mb-3">Seasonal Care</h3>
              <div className="space-y-2 text-sm">
                <p><span className="text-primary font-medium">Spring/Summer:</span> Increase watering frequency and fertilize regularly.</p>
                <p><span className="text-primary font-medium">Fall/Winter:</span> Reduce watering and stop fertilizing. Protect from cold drafts.</p>
              </div>
            </div>
            
            {/* Common Issues */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-100 p-4">
              <h3 className="font-medium mb-3">Common Issues & Solutions</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="font-medium">Yellow Leaves</p>
                  <p className="text-neutral-600">Usually indicates overwatering. Allow soil to dry more between waterings.</p>
                </div>
                <div>
                  <p className="font-medium">Brown Leaf Edges</p>
                  <p className="text-neutral-600">Sign of low humidity. Mist leaves or use a humidifier.</p>
                </div>
                <div>
                  <p className="font-medium">Drooping Leaves</p>
                  <p className="text-neutral-600">Plant may need water or is getting too much direct sunlight.</p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Tab Content: Health Status */}
        {activeTab === 'health' && (
          <div className="fade-in">
            {/* Current Health Status */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-100 p-4 mb-6">
              <div className="flex items-start">
                <div className={`rounded-full p-2 mr-3 ${
                  plantDetails.healthStatus === 'Healthy' 
                    ? 'bg-success-light bg-opacity-10' 
                    : plantDetails.healthStatus === 'Needs attention'
                    ? 'bg-warning-light bg-opacity-10'
                    : 'bg-error-light bg-opacity-10'
                }`}>
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className={`h-5 w-5 ${
                      plantDetails.healthStatus === 'Healthy' 
                        ? 'text-success' 
                        : plantDetails.healthStatus === 'Needs attention'
                        ? 'text-warning'
                        : 'text-error'
                    }`} 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    {plantDetails.healthStatus === 'Healthy' ? (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    ) : (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    )}
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium">Current Health: 
                    <span className={`ml-1 ${
                      plantDetails.healthStatus === 'Healthy' 
                        ? 'text-success' 
                        : plantDetails.healthStatus === 'Needs attention'
                        ? 'text-warning'
                        : 'text-error'
                    }`}>
                      {plantDetails.healthStatus}
                    </span>
                  </h3>
                  <p className="text-neutral-600 text-sm mt-1">{plantDetails.healthAssessment}</p>
                </div>
              </div>
            </div>
            
            {/* Health Indicators */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-100 overflow-hidden mb-6">
              <div className="p-4 border-b border-neutral-100">
                <h3 className="font-medium mb-3">Health Indicators</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-sm">Leaf Color</p>
                      <p className="text-sm font-medium text-success">Excellent</p>
                    </div>
                    <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{width: '90%'}}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-sm">Leaf Structure</p>
                      <p className="text-sm font-medium text-success">Good</p>
                    </div>
                    <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{width: '80%'}}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-sm">Pest Signs</p>
                      <p className="text-sm font-medium text-success">None Detected</p>
                    </div>
                    <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{width: '100%'}}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-sm">Growth Pattern</p>
                      <p className="text-sm font-medium text-success">Normal</p>
                    </div>
                    <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{width: '85%'}}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Improvement Suggestions */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-100 p-4">
              <h3 className="font-medium mb-3">Improvement Suggestions</h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                  <p className="text-sm">Consider rotating the plant periodically to ensure even growth and light exposure.</p>
                </div>
                <div className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                  <p className="text-sm">Clean the leaves occasionally to remove dust and improve photosynthesis.</p>
                </div>
                <div className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                  <p className="text-sm">For optimal growth, provide support for climbing as the plant matures.</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
