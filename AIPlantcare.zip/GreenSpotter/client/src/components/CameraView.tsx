import { useState, useRef } from 'react';
import Webcam from 'react-webcam';
import { Button } from '@/components/ui/button';
import { usePlant } from '@/context/PlantContext';
import { useMobile } from '@/hooks/use-mobile';
import { useToast } from '@/hooks/use-toast';

export default function CameraView() {
  const webcamRef = useRef<Webcam>(null);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const { setCurrentImage, setIsProcessing } = usePlant();
  const { toast } = useToast();
  const isMobile = useMobile();

  const enableCamera = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      setCameraEnabled(true);
    } catch (err) {
      console.error('Error accessing camera:', err);
      toast({
        title: "Camera Access Error",
        description: "Could not access your camera. Please check permissions or use the upload option.",
        variant: "destructive"
      });
    }
  };

  const captureImage = () => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setCurrentImage(imageSrc);
        setIsProcessing(true);
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Store the filename in sessionStorage to use for identification
    const filename = file.name.toLowerCase();
    sessionStorage.setItem('lastUploadedFilename', filename);
    console.log('Image filename:', filename);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setCurrentImage(dataUrl);
      setIsProcessing(true);
    };
    
    reader.onerror = () => {
      toast({
        title: "Error",
        description: "Failed to read the image file",
        variant: "destructive"
      });
    };
    
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex-1 flex flex-col">
      <div className="container mx-auto px-4 py-6 flex-1 flex flex-col">
        <h2 className="text-xl font-medium text-center mb-4">Identify Your Plant</h2>
        
        {/* Camera Viewfinder */}
        <div className="camera-container mx-auto relative bg-black rounded-lg overflow-hidden mb-6 shadow-lg">
          {cameraEnabled ? (
            <Webcam
              audio={false}
              ref={webcamRef}
              screenshotFormat="image/jpeg"
              videoConstraints={{
                facingMode: isMobile ? "environment" : "user"
              }}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex items-center justify-center h-full bg-neutral-800">
              <Button 
                onClick={enableCamera}
                className="bg-primary hover:bg-primary-dark text-white"
              >
                Enable Camera
              </Button>
            </div>
          )}
          
          {/* Scanning Overlay */}
          {cameraEnabled && (
            <>
              <div className="absolute inset-0 pointer-events-none">
                <div className="h-full w-full flex items-center justify-center">
                  <div className="border-2 border-white rounded-lg w-4/5 h-4/5 flex items-center justify-center">
                    <div className="rounded-full w-16 h-16 border-2 border-primary-light pulse"></div>
                  </div>
                </div>
              </div>
              
              {/* Capture Button */}
              <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                <button 
                  className="bg-white rounded-full w-16 h-16 flex items-center justify-center shadow-lg"
                  onClick={captureImage}
                >
                  <div className="bg-primary rounded-full w-14 h-14"></div>
                </button>
              </div>
            </>
          )}
        </div>
        
        {/* Alternative Upload Option */}
        <div className="text-center mb-8">
          <p className="text-neutral-600 mb-3">Or upload an image from your device</p>
          <label htmlFor="file-upload" className="cursor-pointer inline-flex items-center px-4 py-2 bg-white border border-neutral-300 rounded-md shadow-sm text-base font-medium text-neutral-700 hover:bg-neutral-50">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Upload Image
          </label>
          <input 
            id="file-upload" 
            type="file" 
            accept="image/*" 
            className="hidden" 
            onChange={handleFileUpload} 
          />
        </div>
        
        {/* Tips */}
        <div className="bg-white rounded-lg p-4 shadow-sm border border-neutral-200">
          <h3 className="font-medium flex items-center gap-2 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            Tips for best results
          </h3>
          <ul className="text-sm text-neutral-600 space-y-2">
            <li className="flex items-start gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary-light mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Center the plant in frame</span>
            </li>
            <li className="flex items-start gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary-light mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Make sure there's good lighting</span>
            </li>
            <li className="flex items-start gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary-light mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Focus on leaves and distinctive features</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
