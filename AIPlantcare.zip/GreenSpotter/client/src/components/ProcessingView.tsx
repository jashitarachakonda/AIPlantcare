export default function ProcessingView() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4">
      <div className="text-center">
        <div className="inline-block rounded-full bg-primary-light bg-opacity-10 p-6 mb-4">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-primary border-solid"></div>
        </div>
        <h2 className="text-xl font-medium mb-2">Analyzing Your Plant</h2>
        <p className="text-neutral-600 max-w-xs mx-auto">
          We're examining the image to identify your plant and assess its health
        </p>
      </div>
    </div>
  );
}
