import React, { createContext, useContext, useState } from 'react';

export interface PlantDetails {
  id?: number;
  name: string;
  scientificName: string;
  imageUrl: string;
  confidence?: number;
  healthStatus: 'Healthy' | 'Needs attention' | 'Unhealthy';
  healthAssessment: string;
  growthStage: string;
  type: string;
  lightNeeds: string;
  temperatureNeeds: string;
  humidityNeeds: string;
  wateringFrequency: string;
  soilNeeds: string;
  pruningNeeds: string;
  repottingNeeds: string;
  funFact?: string;
  timestamp?: string;
}

interface PlantContextType {
  currentImage: string | null;
  setCurrentImage: (image: string | null) => void;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  plantDetails: PlantDetails | null;
  setPlantDetails: (details: PlantDetails | null) => void;
  scanHistory: PlantDetails[];
  addToHistory: (plant: PlantDetails) => void;
}

const defaultPlantContext: PlantContextType = {
  currentImage: null,
  setCurrentImage: () => {},
  isProcessing: false,
  setIsProcessing: () => {},
  plantDetails: null,
  setPlantDetails: () => {},
  scanHistory: [],
  addToHistory: () => {},
};

const PlantContext = createContext<PlantContextType>(defaultPlantContext);

export const usePlant = () => useContext(PlantContext);

export const PlantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [plantDetails, setPlantDetails] = useState<PlantDetails | null>(null);
  const [scanHistory, setScanHistory] = useState<PlantDetails[]>([]);

  const addToHistory = (plant: PlantDetails) => {
    setScanHistory((prev) => [plant, ...prev]);
  };

  return (
    <PlantContext.Provider
      value={{
        currentImage,
        setCurrentImage,
        isProcessing,
        setIsProcessing,
        plantDetails,
        setPlantDetails,
        scanHistory,
        addToHistory,
      }}
    >
      {children}
    </PlantContext.Provider>
  );
};
