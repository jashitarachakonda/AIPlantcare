import axios from 'axios';
import type { PlantDetails } from '@/context/PlantContext';

export async function identifyPlant(imageBase64: string): Promise<PlantDetails | null> {
  try {
    // Remove data URL prefix (e.g., "data:image/jpeg;base64,")
    const base64Data = imageBase64.split(',')[1];
    
    // Get the filename from sessionStorage if available
    const filename = sessionStorage.getItem('lastUploadedFilename') || '';
    console.log('Sending image with filename:', filename);
    
    const response = await axios.post('/api/identify', { 
      image: base64Data,
      filename: filename  // Pass the filename to the server
    });
    
    return response.data;
  } catch (error) {
    console.error('Error identifying plant:', error);
    
    // Check if this is a server response with a status code
    if (error && typeof error === 'object' && 'response' in error) {
      // If the server specifically said no plant was detected (404)
      if (error.response && typeof error.response === 'object' && 'status' in error.response && error.response.status === 404) {
        console.log('Server response: No plant detected in this image');
      }
    }
    
    return null;
  }
}

export async function savePlantToHistory(plant: PlantDetails): Promise<void> {
  try {
    await axios.post('/api/history', plant);
  } catch (error) {
    console.error('Error saving plant to history:', error);
  }
}

export async function getPlantHistory(): Promise<PlantDetails[]> {
  try {
    const response = await axios.get('/api/history');
    return response.data;
  } catch (error) {
    console.error('Error fetching plant history:', error);
    return [];
  }
}
