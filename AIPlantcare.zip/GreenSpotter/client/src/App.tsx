import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import ResultsView from "@/pages/ResultsView";
import ErrorView from "@/pages/ErrorView";
import { PlantProvider } from "./context/PlantContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/results" component={ResultsView} />
      <Route path="/error" component={ErrorView} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <PlantProvider>
        <Router />
        <Toaster />
      </PlantProvider>
    </QueryClientProvider>
  );
}

export default App;
