import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    // Sample plant data
    const samplePlants = [
      {
        name: "Monstera Deliciosa",
        scientificName: "Monstera deliciosa",
        imageUrl: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        confidence: 96,
        healthStatus: "Healthy",
        healthAssessment: "Your plant appears healthy with vibrant green leaves and good leaf structure. Continue with current care routine.",
        growthStage: "Young Adult (2-3 years)",
        type: "Tropical Houseplant",
        lightNeeds: "Bright, indirect light",
        temperatureNeeds: "65°F - 85°F (18°C - 29°C)",
        humidityNeeds: "Medium to high humidity (60-80%)",
        wateringFrequency: "Water when top 1-2 inches of soil are dry, typically every 1-2 weeks",
        soilNeeds: "Well-draining, rich potting mix. Fertilize monthly during growing season.",
        pruningNeeds: "Remove yellowing or damaged leaves. Prune in spring to control size.",
        repottingNeeds: "Repot every 2-3 years or when roots grow through drainage holes.",
        funFact: "The holes in Monstera leaves are called fenestrations and help the plant withstand heavy rains and allow light to pass to lower leaves."
      },
      {
        name: "Snake Plant",
        scientificName: "Sansevieria trifasciata",
        imageUrl: "https://images.unsplash.com/photo-1572688484438-313a6e50c333?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        confidence: 98,
        healthStatus: "Healthy",
        healthAssessment: "Your snake plant is in excellent condition. The upright leaves show good coloration and firmness.",
        growthStage: "Mature (3+ years)",
        type: "Succulent",
        lightNeeds: "Low to bright indirect light",
        temperatureNeeds: "60°F - 85°F (15°C - 29°C)",
        humidityNeeds: "Low to average humidity (30-50%)",
        wateringFrequency: "Allow soil to dry completely between waterings, every 2-8 weeks",
        soilNeeds: "Well-draining cactus or succulent mix. Fertilize lightly 2-3 times per year.",
        pruningNeeds: "Rarely needed. Remove damaged leaves at the base.",
        repottingNeeds: "Every 2-5 years or when root-bound. Can thrive in crowded conditions.",
        funFact: "Snake plants are one of the most effective air-purifying houseplants, removing toxins like formaldehyde and benzene."
      },
      {
        name: "Fiddle Leaf Fig",
        scientificName: "Ficus lyrata",
        imageUrl: "https://images.unsplash.com/photo-1508022713622-df2d8fb7b4cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        confidence: 95,
        healthStatus: "Needs attention",
        healthAssessment: "Some brown spots on leaf edges indicate possible inconsistent watering or low humidity. Adjust care routine.",
        growthStage: "Young (1-2 years)",
        type: "Tropical Tree",
        lightNeeds: "Bright, indirect light",
        temperatureNeeds: "65°F - 75°F (18°C - 24°C)",
        humidityNeeds: "Medium to high humidity (50-60%)",
        wateringFrequency: "Allow top inch of soil to dry out between waterings, usually every 7-10 days",
        soilNeeds: "Well-draining, rich soil. Fertilize monthly during growing season with balanced fertilizer.",
        pruningNeeds: "Minimal pruning needed. Remove damaged leaves at the stem.",
        repottingNeeds: "Repot annually for young plants, every 2-3 years for mature plants.",
        funFact: "Fiddle leaf figs can grow up to 50 feet tall in their natural habitat in West Africa!"
      }
    ];

    // Insert sample plants
    console.log("Seeding sample plants data...");
    
    for (const plant of samplePlants) {
      // Check if plant already exists by scientific name to avoid duplicates
      const existingPlant = await db.query.plants.findFirst({
        where: (p, { eq }) => eq(p.scientificName, plant.scientificName)
      });
      
      if (!existingPlant) {
        await db.insert(schema.plants).values(plant);
        console.log(`Added plant: ${plant.name}`);
      } else {
        console.log(`Plant ${plant.name} already exists, skipping`);
      }
    }
    
    console.log("Seed completed successfully");
  } catch (error) {
    console.error("Error during seeding:", error);
  }
}

seed();
